<?php

namespace MrBerlin\Dailysystem\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use MrBerlin\Dailysystem\Main;
use MrBerlin\Dailysystem\managers\DailyManager;

class DailyCommand extends Command {

    private Main $plugin;
    private DailyManager $manager;

    public function __construct(Main $plugin) {
        parent::__construct("daily", "Claim your daily reward", "/daily", ["reward"]);

        $this->plugin = $plugin;
        $this->manager = $plugin->getDailyManager();
        $this->setPermission("dailysystem.use");
    }

    public function execute(CommandSender $sender, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Run this command in-game.");
            return true;
        }

        if (!$sender->hasPermission("dailysystem.use")) {
            $sender->sendMessage($this->manager->getMessage("no-permission"));
            return true;
        }

        if (!$this->manager->canClaim($sender)) {
            $time = $this->manager->formatTime($this->manager->getRemaining($sender));
            $sender->sendMessage($this->manager->getMessage("cooldown", ["time" => $time]));
            return true;
        }

        $economy = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");

        if ($economy === null) {
            $sender->sendMessage($this->manager->getMessage("no-economy"));
            return true;
        }

        $amount = $this->manager->getReward();

        \onebone\economyapi\EconomyAPI::getInstance()->addMoney($sender, $amount);
        $this->manager->claim($sender);

        $sender->sendMessage($this->manager->getMessage("success", [
            "amount" => number_format($amount)
        ]));

        return true;
    }
}