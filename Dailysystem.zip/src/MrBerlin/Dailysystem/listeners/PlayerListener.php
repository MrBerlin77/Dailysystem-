<?php

namespace MrBerlin\Dailysystem\listeners;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use MrBerlin\Dailysystem\Main;
use MrBerlin\Dailysystem\managers\DailyManager;

class PlayerListener implements Listener {

    private DailyManager $manager;

    public function __construct(Main $plugin) {
        $this->manager = $plugin->getDailyManager();
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();

        if ($this->manager->canClaim($player)) {
            $player->sendMessage("§6[§eDaily§6] §aYour daily reward is ready. Use §e/daily");
        }
    }
}