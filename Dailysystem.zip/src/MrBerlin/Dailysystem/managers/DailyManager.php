<?php

namespace MrBerlin\Dailysystem\managers;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use MrBerlin\Dailysystem\Main;

class DailyManager {

    private Main $plugin;
    private Config $data;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config($plugin->getDataFolder() . "players.json", Config::JSON);
    }

    public function canClaim(Player $player): bool {
        $last = (int) $this->data->get(strtolower($player->getName()), 0);
        return (time() - $last) >= $this->getCooldown();
    }

    public function getRemaining(Player $player): int {
        $last = (int) $this->data->get(strtolower($player->getName()), 0);
        return max(0, $this->getCooldown() - (time() - $last));
    }

    public function claim(Player $player): void {
        $this->data->set(strtolower($player->getName()), time());
        $this->data->save();
    }

    public function getReward(): int {
        return (int) $this->plugin->getPluginConfig()->getNested("settings.reward-amount", 5000);
    }

    public function getCooldown(): int {
        return (int) $this->plugin->getPluginConfig()->getNested("settings.cooldown", 86400);
    }

    public function getMessage(string $key, array $replace = []): string {
        $prefix = $this->plugin->getPluginConfig()->getNested("settings.prefix", "");
        $msg = $this->plugin->getPluginConfig()->getNested("messages.$key", "");

        foreach ($replace as $k => $v) {
            $msg = str_replace("{" . $k . "}", (string) $v, $msg);
        }

        return $prefix . $msg;
    }

    public function formatTime(int $seconds): string {
        return sprintf(
            "%02d:%02d:%02d",
            floor($seconds / 3600),
            floor(($seconds % 3600) / 60),
            $seconds % 60
        );
    }

    public function save(): void {
        $this->data->save();
    }
}